$(document).ready(function() {
    $("#form_id").validate({
      rules: {
        name : {
          required: true,
          minlength: 3
        },
        email: {
          required: true,
          email: true
        },
        designation: {
            required: true,
            minlength: 3
        },
        contact: {
            required: true,
            number: true,
            minlength:10,
            maxlength:10
           
        }
      },
      messages : {
        name: {
          minlength: "Name should be at least 3 characters"
        },
        email: {
          email: "The email should be in the format: abc@domain.tld"
        },
        designation: {
            designation: "Should be atleast 5 characters"
          },
        contact: {
            contact: "Should enter atleast 10 numbers"
        },
      }
      
    });

   
    
    
    $('.submit').click(function(){
        var name =  $('#id_name').val();
        var email = $('#id_email').val();
        var designation =  $('#id_desig').val();
        var contact =  $('#id_contact').val();
        console.log(name);
       if (name.length < 1 || name  == 'undefined' || name  == 'null'|| 
        email.length < 1  || email  =='undefined' || email  == 'null' ||
        designation.length < 1  || designation  == 'undefined' || designation  == 'null' ||
        contact.length < 1|| contact  == 'undefined' || contact  == 'null' ){
            $('.submit').show();
        }
        else {
	     var storedValues = [];
	     var enteredValues = {};
              enteredValues.name = $('#id_name').val();
	      enteredValues.name = $('#id_email').val();
	      enteredValues.name = $('#id_desig').val();
	      enteredValues.name = $('#id_contact').val();
	      storedValues.push(enteredValues);
	      console.log(storedValues);
	     $(".submitted").css("pointer-events","none");
            $(".submitted").css("display", "block");
            $('.submit').hide();
            return false;
            
        }
    });
       
  });