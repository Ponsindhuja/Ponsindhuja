$(document).ready(function() {
    $("#form_id").validate({
      rules: {
        name : {
          required: true,
          minlength: 3
        },
        email: {
          required: true,
          email: true
        },
        designation: {
            required: true,
            minlength: 3
        },
        contact: {
            required: true,
            number: true,
            matches: "[0-9]+",  // <-- no such method called "matches"!
            minlength:10,
            maxlength:10
           
        }
      },
      messages : {
        name: {
          minlength: "Name should be at least 3 characters"
        },
        email: {
          email: "The email should be in the format: abc@domain.tld"
        },
        designation: {
            designation: "Should be atleast 5 characters"
          },
        contact: {
            contact: "Should enter atleast 10 numbers"
        },
      }
      
    });
    $('.submitted').hide();
    $('.submit').click(function(){
        $('.submitted').show();
        $('.submit').hide();
    });
  });